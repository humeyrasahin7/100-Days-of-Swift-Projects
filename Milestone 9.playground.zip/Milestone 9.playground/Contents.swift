import UIKit
import PlaygroundSupport

//CHALLEGE 1
extension UIView {
    func bounceOut(duration: TimeInterval){
        UIView.animate(withDuration: duration) { [weak self] in
            self?.transform = CGAffineTransform(scaleX: 0.0001, y: 0.0001)
        }
    }
}

let view = UIView(frame: CGRect(origin: .zero, size: CGSize(width: 400, height: 400)))
view.backgroundColor = .blue

let label = UILabel()
label.font = UIFont.systemFont(ofSize: 60)
label.text = "TEST"
label.textColor = .white
label.translatesAutoresizingMaskIntoConstraints = false
label.textAlignment = .center
view.addSubview(label)

NSLayoutConstraint.activate([
    label.leadingAnchor.constraint(equalTo: view.leadingAnchor), label.trailingAnchor.constraint(equalTo: view.trailingAnchor),
    label.topAnchor.constraint(equalTo: view.topAnchor), label.bottomAnchor.constraint(equalTo: view.bottomAnchor)
])

PlaygroundPage.current.liveView = view
label.bounceOut(duration: 8)



//CHALLENGE 2
extension Int{
    func times(time: () -> Void){
        guard self > 0 else {return}
        for _ in 1...self{
                time()
            }
    }
}

5.times {
    print("test")
}

//CHALLENGE 3

extension Array where Element: Comparable{
    mutating func remove(item: Element){
        if let index = self.firstIndex(of: item){
            self.remove(at: index)
        }
    }
}

var testNumbers = [1, 2, 3, 4, 5]
testNumbers.remove(item: 3)
